/*
 * datatypes.h
 *
 *  Created on: Feb 12, 2013
 *      Author: a0414510
 */

#ifndef DATATYPES_H_
#define DATATYPES_H_

typedef unsigned char BYTE;
typedef unsigned int BOOL;
typedef signed int HANDLE;

#endif /* DATATYPES_H_ */
