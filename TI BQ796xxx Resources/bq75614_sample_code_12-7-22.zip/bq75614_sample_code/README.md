# BQ79616-Q1 and TMS570LS1224 (LAUNCH XL2)
*RELEASE: 2020-APR-20*
Built with CCS for Hercules Version: 8.1.0.00011


## Pinout - CONNECTIONS BETWEEN BQ79616EVM AND LAUNCH XL2 (TMS570LS1224): 

* bq79616EVM J17 pin 1 (NC)     -> FLOAT
* bq79616EVM J17 pin 2 (NC)     -> FLOAT
* bq79616EVM J17 pin 3 (NFAULT) -> LAUNCH XL2 J4 pin 10 (PA0)
* bq79616EVM J17 pin 4 (NC)     -> FLOAT
* bq79616EVM J17 pin 5 (GND)    -> LAUNCH XL2 J3 pin 2  (GND)
* bq79616EVM J17 pin 6 (3V3)    -> LAUNCH XL2 J2 pin 1  (3V3)
* bq79616EVM J17 pin 7 (RX)     -> LAUNCH XL2 J2 pin 4  (UATX)
* bq79616EVM J17 pin 8 (TX)     -> LAUNCH XL2 J2 pin 3  (UARX)
* bq79616EVM J17 pin 9 (NC)     -> FLOAT
* bq79616EVM J17 pin 10 (NC)    -> FLOAT


## RELEVANT MODIFIED FILES:

* bq79616.h        must change TOTALBOARDS and MAXBYTES here for code to function
* bq79616.c        contains all relevant functions used in the sample code
* notification.c   sets UART_RX_RDY and RTI_TIMEOUT when their respective interrupts happen
* .dil/.hcg        used for generating the basic TMS570LS1224 code files, can be used to make changes to the microcontroller


## PRINTCONSOLE() SETUP:

### FTDI connector

Keep the USB connector side of an FTDI connector in-tact, as this will be used to read the printing on the PC. Cut off the 6-pin connector side of an FTDI cable, and solder the following wires directly to the LAUNCH XL2:


* FTDI CONNECTOR BLACK (PC-GND)   -> LAUNCH XL2 J7 pin 2 (GND)
* FTDI CONNECTOR BROWN            -> NC
* FTDI CONNECTOR RED              -> NC
* FTDI CONNECTOR ORANGE           -> NC
* FTDI CONNECTOR YELLOW (PC-RX)   -> LAUNCH XL2 J6 pin 4 (TX)
* FTDI CONNECTOR GREEN            -> NC

### PuTTY setup

Ensure FTDI drivers and PuTTY (https://www.chiark.greenend.org.uk/~sgtatham/putty/) are installed before starting. Please note that the following steps must be completed every time a new FTDI cable is used on the PC.

1. Unplug your FTDI USB cable if connected
2. Open "Device Manager" on PC
3. Plug in the FTDI USB cable, observing which "COM" port shows up in the "COM port" portion of Device Manager. This is your COM port in PuTTY
4. Open PuTTY
5. Choose "Connection Type" as Serial
6. Set "Speed" as 1000000
7. Set "Serial line" as the COM port you noted in step 3, i.e. "COM1"
8. Optionally, type a name like "TMS570 terminal" in "Saved Sessions", and then click "Save" to save these settings for future debugging. You can then double-click the saved session in the future to auto-load all of these settings.
9. Click "Open"